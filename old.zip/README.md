# SQL_visualizer
 rendering machine chart
